import FullCalendar from '@fullcalendar/react'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export default function Calendario() {
  const [eventos, setEventos] = useState([])

  useEffect(() => {
    async function carregar() {
      const { data } = await supabase
        .from('horarios_disponiveis')
        .select('*')
        .eq('reservado', false)

      if (data) {
        const evs = data.map((h: any) => ({
          id: h.id,
          title: 'Disponível',
          start: `${h.data}T${h.hora_inicio}`,
          end: `${h.data}T${h.hora_fim}`,
          color: '#22c55e'
        }))
        setEventos(evs)
      }
    }

    carregar()
  }, [])

  const agendar = async (info: any) => {
    const ok = confirm('Deseja agendar este horário?')
    if (!ok) return

    const id = info.event.id
    await supabase.from('horarios_disponiveis').update({ reservado: true }).eq('id', id)
    await supabase.from('agendamentos').insert({
      horario_id: id,
      professor_id: 'USER_ID_EXEMPLO',
      status: 'pendente'
    })

    setEventos(e => e.filter(ev => ev.id !== id))
  }

  return (
    <FullCalendar
      plugins={[timeGridPlugin, interactionPlugin]}
      initialView="timeGridWeek"
      events={eventos}
      eventClick={agendar}
      allDaySlot={false}
    />
  )
}