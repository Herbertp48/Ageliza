import Calendario from './components/Calendario'

function App() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Agendamentos</h1>
      <Calendario />
    </div>
  )
}

export default App